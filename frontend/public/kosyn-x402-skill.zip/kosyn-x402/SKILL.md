# Kosyn x402 Health Data API — Claude Skill

Load this file into your Claude context to get AI-assisted integration with the Kosyn Health Analytics API.

## What is x402?

x402 is an HTTP-native micropayment protocol. Instead of API keys, callers pay on-chain and present the transaction hash as proof. The server verifies on-chain and returns data.

Flow: `GET /endpoint → 402 → pay on-chain → GET /endpoint + X-Payment: <tx_hash> → 200`

---

## Kosyn API

**Base URL:** `https://kosyn.app/api/data`
**Chain:** Avalanche Fuji (chainId: 43113)
**Payment Token:** KUSD (KosynUSD ERC-20)

### Endpoints

| Path | Price | Description |
|------|-------|-------------|
| `/api/data/demographics` | 10 KUSD | Age/gender distribution (k-anonymity k≥10) |
| `/api/data/conditions` | 25 KUSD | Top conditions from consultation records (ε=0.1 DP) |
| `/api/data/outcomes` | 50 KUSD | Treatment outcome correlations (synthetic noise) |

All data aggregated inside Chainlink CRE TEE enclaves. Raw patient data never leaves the secure boundary.

---

## 402 Response Format

```json
{
  "x402Version": 1,
  "error": "Payment Required",
  "accepts": [{
    "scheme": "exact",
    "network": "eip155:43113",
    "maxAmountRequired": "10000000000000000000",
    "resource": "/api/data/demographics",
    "description": "Age/gender distribution across consenting patients",
    "payTo": "0x<DataMarketplace address>",
    "currency": "KUSD"
  }]
}
```

---

## Contract ABIs

### KosynUSD (ERC-20)
```solidity
function balanceOf(address account) external view returns (uint256);
function approve(address spender, uint256 amount) external returns (bool);
function transferFrom(address from, address to, uint256 amount) external returns (bool);
```

### DataMarketplace
```solidity
function submitQuery(string calldata queryParams, uint256 payment) external;
function queryCount() external view returns (uint256);
function listings(address patient) external view returns (address patient, bool isActive);
```

---

## Full Integration Example (JavaScript / thirdweb)

```javascript
import { prepareContractCall, getContract } from "thirdweb";
import { avalancheFuji } from "thirdweb/chains";

const KUSD_ADDRESS = process.env.NEXT_PUBLIC_KOSYNUSD;
const MARKETPLACE_ADDRESS = process.env.NEXT_PUBLIC_DATA_MARKETPLACE;

async function queryKosynAPI(endpoint, priceKUSD, sendTx) {
  const priceWei = BigInt(priceKUSD * 1e18);
  const kosynUSD = getContract({ client, chain: avalancheFuji, address: KUSD_ADDRESS });
  const marketplace = getContract({ client, chain: avalancheFuji, address: MARKETPLACE_ADDRESS });

  // Step 1: Check if payment required
  const probe = await fetch(`https://kosyn.app/api/data/${endpoint}`);
  if (probe.status !== 402) return probe.json(); // already accessible (shouldn't happen)

  // Step 2: Approve KUSD spend
  await sendTx(prepareContractCall({
    contract: kosynUSD,
    method: "function approve(address, uint256) returns (bool)",
    params: [MARKETPLACE_ADDRESS, priceWei],
  }));

  // Step 3: Submit payment — DataMarketplace emits QuerySubmitted(queryId, caller, amount)
  const receipt = await sendTx(prepareContractCall({
    contract: marketplace,
    method: "function submitQuery(string, uint256)",
    params: [endpoint, priceWei],
  }));

  // Step 4: Retry with proof
  const res = await fetch(`https://kosyn.app/api/data/${endpoint}`, {
    headers: { "X-Payment": receipt.transactionHash },
  });

  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// Usage
const data = await queryKosynAPI("demographics", 10, sendTx);
console.log(data.total_patients); // 847
console.log(data.age_distribution); // { "18-30": 23, "31-45": 38, ... }
```

---

## Full Integration Example (Python / web3.py)

```python
import requests
from web3 import Web3

RPC = "https://api.avax-test.network/ext/bc/C/rpc"
w3 = Web3(Web3.HTTPProvider(RPC))

KUSD_ADDRESS = "0x<KosynUSD address>"
MARKETPLACE_ADDRESS = "0x<DataMarketplace address>"

KUSD_ABI = [{"name": "approve", "type": "function", "inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}]}]
MARKETPLACE_ABI = [{"name": "submitQuery", "type": "function", "inputs": [{"name": "queryParams", "type": "string"}, {"name": "payment", "type": "uint256"}], "outputs": []}]

kusd = w3.eth.contract(address=KUSD_ADDRESS, abi=KUSD_ABI)
marketplace = w3.eth.contract(address=MARKETPLACE_ADDRESS, abi=MARKETPLACE_ABI)

def query_kosyn(endpoint, price_kusd, account, private_key):
    price_wei = price_kusd * 10**18

    # Approve
    tx = kusd.functions.approve(MARKETPLACE_ADDRESS, price_wei).build_transaction({
        "from": account, "nonce": w3.eth.get_transaction_count(account)
    })
    signed = w3.eth.account.sign_transaction(tx, private_key)
    w3.eth.send_raw_transaction(signed.rawTransaction)

    # Pay
    tx2 = marketplace.functions.submitQuery(endpoint, price_wei).build_transaction({
        "from": account, "nonce": w3.eth.get_transaction_count(account)
    })
    signed2 = w3.eth.account.sign_transaction(tx2, private_key)
    tx_hash = w3.eth.send_raw_transaction(signed2.rawTransaction)

    # Fetch
    res = requests.get(
        f"https://kosyn.app/api/data/{endpoint}",
        headers={"X-Payment": tx_hash.hex()}
    )
    return res.json()
```

---

## Environment Variables

```env
NEXT_PUBLIC_KOSYNUSD=0x...
NEXT_PUBLIC_DATA_MARKETPLACE=0x...
NEXT_PUBLIC_AVALANCHE_FUJI_RPC_URL=https://api.avax-test.network/ext/bc/C/rpc
```

---

## How CRE Distribution Works

After `submitQuery()` is called on-chain:
1. DataMarketplace emits `QuerySubmitted(queryId, caller, amount)`
2. Chainlink CRE Log Trigger detects the event
3. CRE workflow runs inside TEE enclave on the DON
4. Workflow reads `listings` mapping to find active patient contributors
5. Computes proportional KUSD shares
6. Writes distribution report to HealthRecordRegistry via EVM Write
7. KUSD transferred to each contributing patient wallet

End-to-end: researcher pays → patients earn. No intermediary. Fully on-chain.
